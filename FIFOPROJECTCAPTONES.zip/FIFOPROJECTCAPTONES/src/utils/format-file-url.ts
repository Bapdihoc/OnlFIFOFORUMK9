export const formatFileFirebaseUrl = (url: string) => {
    return url.replace('firebase', 'firebasestorage');
}
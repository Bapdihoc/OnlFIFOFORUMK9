import GoogleIcon from '@/assets/icons/Google.svg';
import StarIcon from '@/assets/icons/star-icon.svg';
import SuccessfulIcon from '@/assets/icons/Sticker.svg';
import Logo from '@/assets/logos/FIFO logo.png';

export { GoogleIcon, Logo, StarIcon, SuccessfulIcon };

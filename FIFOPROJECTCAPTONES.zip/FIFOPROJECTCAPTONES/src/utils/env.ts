const API_PATH = import.meta.env.VITE_API_PATH;

export {
    API_PATH
}
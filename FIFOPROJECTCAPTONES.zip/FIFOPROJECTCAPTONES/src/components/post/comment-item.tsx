import React from 'react'

const CommentItem = () => {
  return (
    <div>CommentItem</div>
  )
}

export default CommentItem
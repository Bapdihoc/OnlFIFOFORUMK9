export const LocalStorageKeys = {
    ACCESS_TOKEN_KEY: 'access_token',
    REFRESH_TOKEN_KEY: 'refresh_token',
    USERNAME_KEY: 'username',
    USER_ID_KEY: 'user_id',
    USER_ROLES_KEY: 'roles',
    LOCALE_KEY: 'locale',
    IS_NEW_USER_KEY: 'newUser',
};


#### LIST PAGES


#### Ngọc Sơn
- [ ] Sign up 
- [ ] Sign in
- [ ] Forgot password
- [ ] Create new password
- [ ] Wallet
- [ ] Notification page

#### Minh Đức
- [ ] Home page
- [ ] Create post
- [ ] Post detail
- [ ] Event page
- [ ] Event detail page
- [ ] Help + Content policies + About
- [ ] Profile [Posts, Medias, Replies]
 